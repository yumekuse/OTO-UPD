home.jpg is OTO's official home screen picture. The home screen always shows it (players can't change it).
To change it for everyone: replace home.jpg and ship an update, or publish an update with
  python Server/publish-update.py <version> --wallpaper <image>
(the game downloads that picture at start and uses it instead of this file).
The other wallpapers (StreamingAssets/Wallpapers) are only used behind menus and songs that have no art.
