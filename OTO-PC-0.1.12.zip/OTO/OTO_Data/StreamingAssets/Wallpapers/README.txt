Put wallpaper images here (PNG or JPG).
Every time OTO starts, it shows a random one on the main menu (and behind the other screens).
Images in this folder get packed into every build, including the Android APK.
You can also drop images into the game's data folder > Wallpapers on PC (Settings > Video > Wallpapers folder) without rebuilding.

This folder is git-ignored on purpose: only use art you have the rights to, and never commit other people's
artwork to the repository. With no wallpapers, OTO shows its own animated background.
